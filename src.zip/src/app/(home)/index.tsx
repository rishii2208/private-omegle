import { View, Text } from 'react-native';
import React from 'react';

const index = () => {
  return (
    <View>
      <Text>index</Text>
    </View>
  );
};

export default index;
